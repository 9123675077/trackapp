from django.apps import AppConfig


class TrackappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'trackapp'
