from django.shortcuts import render,redirect
from django.contrib import messages
from .forms import EditUserProfile
from accounts.models import hello
from django.contrib.auth.models import User,auth
from django.contrib.auth.decorators import login_required

# Create your views here.
          
def signup(request):
  if request.method == 'POST':
     first_name = request.POST['first_name']
     last_name = request.POST['last_name']
     username = request.POST['username']
     password = request.POST['password']
     password1 = request.POST['password1']
     email = request.POST['email']
     


     if password == password1:
        if User.objects.filter(username=username).exists():
            messages.info(request,'username exist')
            return redirect('signup')
        elif User.objects.filter(email=email).exists():
            messages.info(request,'email exist')
            return redirect('signup')
        else:        
            user = User.objects.create_user(username=username,password=password,email=email,first_name=first_name,last_name=last_name)
            user.save()
    
            print('account created')
            return redirect('login') 
     else:
        messages.info(request,'password not match') 
        return redirect('signup')
     return redirect('/')   
  else:       
     return render(request,'signup.html')

def login(request):
    if request.method == 'POST':
       username = request.POST['username']
       password = request.POST['password']

       user = auth.authenticate(username=username,password=password)
       if user is not None:
           auth.login(request,user)
           return redirect("/")
       else:
           messages.info(request,'invalid details') 
           return redirect('login')
    else:
       return render(request,'login.html')

def logout(request):
    auth.logout(request)
    return redirect('/')  
@login_required
def studentdata(request):    
    if request.method == 'POST':
        if request.POST.get('full_name') and request.POST.get('father_name') and request.POST.get('address') and request.POST.get('gender') and request.POST.get('state') and request.POST.get('city') and request.POST.get('birth_date') and request.POST.get('pincode') and request.POST.get('course') and request.POST.get('skills'):
            saverecord=hello()
            saverecord.user = request.POST.get('user')
            saverecord.full_name = request.POST.get('full_name')
            saverecord.father_name = request.POST.get('father_name')
            saverecord.address = request.POST.get('address')
            saverecord.gender = request.POST.get('gender')
            saverecord.state = request.POST.get('state')
            saverecord.city = request.POST.get('city')
            saverecord.birth_date = request.POST.get('birth_date')
            saverecord.pincode = request.POST.get('pincode')
            saverecord.course = request.POST.get('course')
            saverecord.skills = request.POST.get('skills')
        
            saverecord.save(messages.success(request,'done'))
            return redirect('/')
            
    else:       
        return render(request,'studentdata.html')
@login_required        
def studentrecivedata(request):
    details=hello.objects.all()

    return render(request,"studentrecivedata.html",{'hello':details})     
def asif(request):
    if request.user.is_authenticated:
        if request.method =="POST":
            fm =EditUserProfile(request.Post, instance=request.user)
            if fm.is_valid():
                fm.save()
        else:        
            fm =EditUserProfile(instance=request.user)
            return render(request,"asif.html",{'name':request.user, 'form':fm})   
    else:
        return redirect('asif')     
def profile(request):
    context = {}
    check = register_table.objects.filter(user__id=request.user.id)
    if len(check)>0:
        data = register_table.objects.get(user__id=request.user.id)
        context["data"]=data    
    if request.method=="POST":
        fn = request.POST["fname"]
        ln = request.POST["lname"]
        em = request.POST["email"]
        con = request.POST["contact"]
        age = request.POST["age"]
        ct = request.POST["city"]
        gen = request.POST["gender"]
        occ = request.POST["occ"]
        abt = request.POST["about"]

        usr = User.objects.get(id=request.user.id)
        usr.first_name = fn
        usr.last_name = ln
        usr.email = em
        usr.save()

        data.contact_number = con
        data.age = age
        data.city = ct
        data.gender = gen
        data.occupation = occ
        data.about = abt
        data.save()

        if "image" in request.FILES:
            img = request.FILES["image"]
            data.profile_pic = img
            data.save()


        context["status"] = "Changes Saved Successfully"
    return render(request,"edit_profile.html",context)