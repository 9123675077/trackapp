from django.contrib import admin
from django.urls import path
from . import views
urlpatterns = [
    path("signup", views.signup, name="signup"),
    path("login", views.login, name="login"),
    path("logout", views.logout, name="logout"),
    path("studentdata", views.studentdata,name="studentdata"),
    path("studentrecivedata", views.studentrecivedata,name="studentrecivedata"),
    path("asif", views.asif, name="asif"),
    path("profile", views.profile, name="profile"),
 ]